package test;


public enum Symbole {
	  COEUR,
	  PIQUE,
	  CARRE,
	  TREFLE,
	  CERISE,
	  CITRON,
	  ORANGE,
	  CLOCHE,
	  BAR,
	  SEPT,
	  SUPER,
	  FREE,
	  BONUS,
	}
